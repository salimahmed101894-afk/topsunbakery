# Top Sun Bakery System

Simple Flask + SQLite bakery management starter for Top Sun Bakery.

## Main sections
- Dashboard
- Production (including damaged/spoiled)
- Sales (Cash, CBE, Telebirr, Credit)
- Branch transfers
- Expenses
- Stock card / carry-over
- Borrowed bakery items

## Render
Build Command:
`pip install -r requirements.txt`

Start Command:
`gunicorn app:app`

The SQLite database is created automatically on first run.
