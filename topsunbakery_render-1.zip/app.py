from flask import Flask, request, redirect, url_for, render_template_string, flash
import sqlite3
from datetime import date

app = Flask(__name__)
app.secret_key = "topsunbakery-secret-key"
DB = "topsunbakery.db"

PRODUCTS = ["Bread", "Cake", "Biscuit"]

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS production (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        product TEXT NOT NULL,
        quantity REAL NOT NULL,
        damaged REAL DEFAULT 0,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        product TEXT NOT NULL,
        quantity REAL NOT NULL,
        amount REAL NOT NULL,
        payment_type TEXT NOT NULL,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS transfers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        product TEXT NOT NULL,
        branch TEXT NOT NULL,
        quantity REAL NOT NULL,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        name TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS stock (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        product TEXT NOT NULL,
        opening REAL DEFAULT 0,
        produced REAL DEFAULT 0,
        transferred REAL DEFAULT 0,
        sold REAL DEFAULT 0,
        damaged REAL DEFAULT 0,
        closing REAL DEFAULT 0,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS borrowings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        work_date TEXT NOT NULL,
        person TEXT NOT NULL,
        item TEXT NOT NULL,
        quantity REAL NOT NULL,
        due_date TEXT,
        note TEXT
    );
    """)
    conn.commit()
    conn.close()

init_db()

STYLE = """
<style>
body{font-family:Arial,sans-serif;background:#f5f2ed;margin:0;color:#2b241f}
header{background:#6b4b2a;color:white;padding:16px}
nav a{color:white;margin-right:14px;text-decoration:none;font-weight:bold}
.container{max-width:1100px;margin:20px auto;padding:0 14px}
.card{background:white;border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 2px 8px #0001}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}
input,select,button{padding:10px;border:1px solid #ccc;border-radius:7px;width:100%;box-sizing:border-box}
button{background:#6b4b2a;color:white;border:0;font-weight:bold;cursor:pointer}
table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left}
h1,h2{margin-top:0}.money{font-size:24px;font-weight:bold}
.msg{background:#e9f6e9;padding:10px;border-radius:7px;margin-bottom:12px}
</style>
"""

LAYOUT = STYLE + """
<header>
 <div style="font-size:22px;font-weight:bold">☀️ TOP SUN BAKERY</div>
 <nav style="margin-top:10px">
 <a href="/">Dashboard</a><a href="/production">Production</a><a href="/sales">Sales</a>
 <a href="/transfers">Branches</a><a href="/expenses">Expenses</a><a href="/stock">Stock</a>
 <a href="/borrowings">Borrowed Items</a>
 </nav>
</header>
<div class="container">
{% with messages=get_flashed_messages() %}{% for m in messages %}<div class="msg">{{m}}</div>{% endfor %}{% endwith %}
{{body|safe}}
</div>
"""

def page(body, **ctx):
    return render_template_string(LAYOUT, body=render_template_string(body, **ctx))

@app.route("/")
def dashboard():
    today = date.today().isoformat()
    conn=db()
    production = conn.execute("SELECT COALESCE(SUM(quantity),0) n FROM production WHERE work_date=?", (today,)).fetchone()["n"]
    damaged = conn.execute("SELECT COALESCE(SUM(damaged),0) n FROM production WHERE work_date=?", (today,)).fetchone()["n"]
    sales = conn.execute("SELECT COALESCE(SUM(amount),0) n FROM sales WHERE work_date=?", (today,)).fetchone()["n"]
    expenses = conn.execute("SELECT COALESCE(SUM(amount),0) n FROM expenses WHERE work_date=?", (today,)).fetchone()["n"]
    conn.close()
    body="""<h1>Dashboard</h1>
    <p>Today: <b>{{today}}</b></p>
    <div class="grid">
      <div class="card"><div>Total Produced</div><div class="money">{{production}}</div></div>
      <div class="card"><div>Damaged</div><div class="money">{{damaged}}</div></div>
      <div class="card"><div>Total Sales</div><div class="money">{{"%.2f"|format(sales)}} Birr</div></div>
      <div class="card"><div>Expenses</div><div class="money">{{"%.2f"|format(expenses)}} Birr</div></div>
    </div>
    <div class="card"><h2>Daily Net Cash View</h2>
    <div class="money">{{"%.2f"|format(sales-expenses)}} Birr</div>
    <p>This is a simple sales-minus-expenses view; full product profit/costing can be added later.</p></div>"""
    return page(body,today=today,production=production,damaged=damaged,sales=sales,expenses=expenses)

@app.route("/production", methods=["GET","POST"])
def production():
    if request.method=="POST":
        conn=db()
        conn.execute("INSERT INTO production(work_date,product,quantity,damaged,note) VALUES(?,?,?,?,?)",
                     (request.form["work_date"],request.form["product"],request.form["quantity"],request.form.get("damaged",0),request.form.get("note","")))
        conn.commit(); conn.close(); flash("Production saved.")
        return redirect(url_for("production"))
    conn=db(); rows=conn.execute("SELECT * FROM production ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Production</h1><div class="card"><form method="post">
    <div class="grid"><input type="date" name="work_date" value="{{today}}" required>
    <select name="product">{% for p in products %}<option>{{p}}</option>{% endfor %}</select>
    <input type="number" step="0.01" name="quantity" placeholder="Total produced" required>
    <input type="number" step="0.01" name="damaged" placeholder="Damaged/spoiled" value="0">
    <input name="note" placeholder="Note"></div><br><button>Save Production</button></form></div>
    <div class="card"><h2>Recent Production</h2><table><tr><th>Date</th><th>Product</th><th>Produced</th><th>Damaged</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.product}}</td><td>{{r.quantity}}</td><td>{{r.damaged}}</td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),products=PRODUCTS,rows=rows)

@app.route("/sales", methods=["GET","POST"])
def sales():
    if request.method=="POST":
        conn=db()
        conn.execute("INSERT INTO sales(work_date,product,quantity,amount,payment_type,note) VALUES(?,?,?,?,?,?)",
                     (request.form["work_date"],request.form["product"],request.form["quantity"],request.form["amount"],request.form["payment_type"],request.form.get("note","")))
        conn.commit(); conn.close(); flash("Sale saved.")
        return redirect(url_for("sales"))
    conn=db(); rows=conn.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Sales</h1><div class="card"><form method="post"><div class="grid">
    <input type="date" name="work_date" value="{{today}}" required>
    <select name="product">{% for p in products %}<option>{{p}}</option>{% endfor %}</select>
    <input type="number" step="0.01" name="quantity" placeholder="Quantity" required>
    <input type="number" step="0.01" name="amount" placeholder="Amount (Birr)" required>
    <select name="payment_type"><option>Cash</option><option>CBE</option><option>Telebirr</option><option>Credit</option></select>
    <input name="note" placeholder="Note"></div><br><button>Save Sale</button></form></div>
    <div class="card"><h2>Recent Sales</h2><table><tr><th>Date</th><th>Product</th><th>Qty</th><th>Amount</th><th>Payment</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.product}}</td><td>{{r.quantity}}</td><td>{{r.amount}}</td><td>{{r.payment_type}}</td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),products=PRODUCTS,rows=rows)

@app.route("/transfers", methods=["GET","POST"])
def transfers():
    if request.method=="POST":
        conn=db()
        conn.execute("INSERT INTO transfers(work_date,product,branch,quantity,note) VALUES(?,?,?,?,?)",
                     (request.form["work_date"],request.form["product"],request.form["branch"],request.form["quantity"],request.form.get("note","")))
        conn.commit(); conn.close(); flash("Branch transfer saved.")
        return redirect(url_for("transfers"))
    conn=db(); rows=conn.execute("SELECT * FROM transfers ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Branch Transfers</h1><div class="card"><form method="post"><div class="grid">
    <input type="date" name="work_date" value="{{today}}" required>
    <select name="product">{% for p in products %}<option>{{p}}</option>{% endfor %}</select>
    <input name="branch" placeholder="Branch name" required><input type="number" step="0.01" name="quantity" placeholder="Quantity" required>
    <input name="note" placeholder="Note"></div><br><button>Save Transfer</button></form></div>
    <div class="card"><table><tr><th>Date</th><th>Product</th><th>Branch</th><th>Qty</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.product}}</td><td>{{r.branch}}</td><td>{{r.quantity}}</td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),products=PRODUCTS,rows=rows)

@app.route("/expenses", methods=["GET","POST"])
def expenses():
    if request.method=="POST":
        conn=db()
        conn.execute("INSERT INTO expenses(work_date,name,amount,note) VALUES(?,?,?,?)",
                     (request.form["work_date"],request.form["name"],request.form["amount"],request.form.get("note","")))
        conn.commit(); conn.close(); flash("Expense saved.")
        return redirect(url_for("expenses"))
    conn=db(); rows=conn.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Expenses</h1><div class="card"><form method="post"><div class="grid">
    <input type="date" name="work_date" value="{{today}}" required><input name="name" placeholder="Expense name (flour, electricity, yeast...)" required>
    <input type="number" step="0.01" name="amount" placeholder="Amount (Birr)" required><input name="note" placeholder="Note"></div><br><button>Save Expense</button></form></div>
    <div class="card"><table><tr><th>Date</th><th>Name</th><th>Amount</th><th>Note</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.name}}</td><td>{{r.amount}}</td><td>{{r.note}}</td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),rows=rows)

@app.route("/stock", methods=["GET","POST"])
def stock():
    if request.method=="POST":
        opening=float(request.form.get("opening",0)); produced=float(request.form.get("produced",0))
        transferred=float(request.form.get("transferred",0)); sold=float(request.form.get("sold",0)); damaged=float(request.form.get("damaged",0))
        closing=opening+produced-transferred-sold-damaged
        conn=db()
        conn.execute("""INSERT INTO stock(work_date,product,opening,produced,transferred,sold,damaged,closing,note)
                     VALUES(?,?,?,?,?,?,?,?,?)""",(request.form["work_date"],request.form["product"],opening,produced,transferred,sold,damaged,closing,request.form.get("note","")))
        conn.commit(); conn.close(); flash(f"Stock saved. Closing stock: {closing}")
        return redirect(url_for("stock"))
    conn=db(); rows=conn.execute("SELECT * FROM stock ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Stock Card</h1><div class="card"><form method="post"><div class="grid">
    <input type="date" name="work_date" value="{{today}}" required><select name="product">{% for p in products %}<option>{{p}}</option>{% endfor %}</select>
    <input type="number" step="0.01" name="opening" placeholder="Opening / carry-over" value="0">
    <input type="number" step="0.01" name="produced" placeholder="Produced" value="0">
    <input type="number" step="0.01" name="transferred" placeholder="Sent to branches" value="0">
    <input type="number" step="0.01" name="sold" placeholder="Sold at main house" value="0">
    <input type="number" step="0.01" name="damaged" placeholder="Damaged/spoiled" value="0">
    <input name="note" placeholder="Note"></div><br><button>Calculate & Save Stock</button></form></div>
    <div class="card"><table><tr><th>Date</th><th>Product</th><th>Opening</th><th>Produced</th><th>Branches</th><th>Sold</th><th>Damaged</th><th>Closing</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.product}}</td><td>{{r.opening}}</td><td>{{r.produced}}</td><td>{{r.transferred}}</td><td>{{r.sold}}</td><td>{{r.damaged}}</td><td><b>{{r.closing}}</b></td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),products=PRODUCTS,rows=rows)

@app.route("/borrowings", methods=["GET","POST"])
def borrowings():
    if request.method=="POST":
        conn=db()
        conn.execute("INSERT INTO borrowings(work_date,person,item,quantity,due_date,note) VALUES(?,?,?,?,?,?)",
                     (request.form["work_date"],request.form["person"],request.form["item"],request.form["quantity"],request.form.get("due_date",""),request.form.get("note","")))
        conn.commit(); conn.close(); flash("Borrowed item recorded.")
        return redirect(url_for("borrowings"))
    conn=db(); rows=conn.execute("SELECT * FROM borrowings ORDER BY id DESC LIMIT 50").fetchall(); conn.close()
    body="""<h1>Borrowed Bakery Items</h1><div class="card"><form method="post"><div class="grid">
    <input type="date" name="work_date" value="{{today}}" required><input name="person" placeholder="Person / bakery" required>
    <input name="item" placeholder="Item borrowed" required><input type="number" step="0.01" name="quantity" placeholder="Quantity" required>
    <input type="date" name="due_date"><input name="note" placeholder="Note"></div><br><button>Save Borrowing</button></form></div>
    <div class="card"><table><tr><th>Date</th><th>From</th><th>Item</th><th>Qty</th><th>Due</th></tr>
    {% for r in rows %}<tr><td>{{r.work_date}}</td><td>{{r.person}}</td><td>{{r.item}}</td><td>{{r.quantity}}</td><td>{{r.due_date}}</td></tr>{% endfor %}</table></div>"""
    return page(body,today=date.today().isoformat(),rows=rows)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
